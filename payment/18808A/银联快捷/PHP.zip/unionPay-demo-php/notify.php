<?php
	$data = array();
	$data = $_REQUEST;
	
	// 商户编号
	// $data['merCode'];
	
	// 订单号
	// $data['orderNo'];
	
	// 订单金额
	// $data['orderAmount'];
	
	// 支付时间
	// $data['payDate'];
	
	// 支付类型
	// $data['payType'];
	
	// 订单状态
	// $data['orderStatus'];
	
	// 返回状态码
	// $data['resultCode'];
	
	// 返回信息
	// $data['resultMsg'];
	
	// 返回状态
	// $data['resultStatus'];
	
	// 返回时间
	// $data['resultTime'];
	
	// some thing code ......