﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace JRAPI_NET_DEMO
{
    public partial class jump : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            string partner = "37210";//商户ID
            string Key = "5e6522049b5fbb8e2c708df54a3e2143";//商户KEY
            int orderstatus = Convert.ToInt32(Request["orderstatus"]);
            string ordernumber = Request["ordernumber"];
            string paymoney = Request["paymoney"];
            string sign = Request["sign"];
            string attach = Request["attach"];
            string signSource = string.Format("partner={0}&ordernumber={1}&orderstatus={2}&paymoney={3}{4}", partner, ordernumber, orderstatus, paymoney, Key);
            if (!string.IsNullOrWhiteSpace(sign))
            {
                if (sign.ToUpper() == JRAPICommon.MD5(signSource, false).ToUpper())//签名正确
                {
                    //此处作逻辑处理

                    //测试代码，输入信息
                    this.Label_MSG.Text = string.Format("订单：{0}，支付：{1}", ordernumber, orderstatus == 1 ? "成功" : "失败");
                    this.Literal_info.Text = "<div class='okinfo'><icon class='icon'></icon>同步回调成功</div>";
                }
                else
                {
                    //测试代码，输入信息
                    this.Literal_info.Text = "<div class='errorinfo'><icon class='icon'></icon>同步回调失败</div>";
                    this.Label_MSG.Text = "签名验证失败";
                }
            }
            else
            {
                //测试代码，输入信息
                this.Literal_info.Text = "<div class='errorinfo'><icon class='icon'></icon>同步回调失败</div>";
                this.Label_MSG.Text = "请查看参数是否完整";
             
            }
           
        }
    }
}