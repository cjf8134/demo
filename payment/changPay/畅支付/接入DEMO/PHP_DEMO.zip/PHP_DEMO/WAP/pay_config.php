<?php


//商户号
$partner['partner'] = '17178';

// MD5密钥，安全检验码，由数字和字母组成的字符串，请登录商户后台查看
$Key['key']	= 'd3b81a4642a00c884f8da472d70a0608';

//网关接口地址
$apiurl['apiurl'] = "http://api.baodaoxp.com/PayBank.aspx";

// 服务器异步通知页面路径  需http://格式的完整路径，不能加?id=123这类自定义参数，必须外网可以正常访问
$callbackurl['callbackurl'] = "http://demo.390pay.com/wap/callbackurl.php";

// 页面跳转同步通知页面路径 需http://格式的完整路径，不能加?id=123这类自定义参数，必须外网可以正常访问
$hrefbackurl['hrefbackurl'] = "http://demo.390pay.com/wap/hrefbackurl.php";

//↑↑↑↑↑↑↑↑↑↑请在这里配置您的基本信息↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑

?>