/*    */ import java.io.IOException;
/*    */ import java.io.PrintStream;
/*    */ import java.io.PrintWriter;
/*    */ import java.util.Map;
/*    */ import javax.servlet.ServletException;
/*    */ import javax.servlet.http.HttpServlet;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ import org.apache.log4j.Logger;
/*    */ 
/*    */ public class demo
/*    */   extends HttpServlet
/*    */ {
/* 18 */   Logger logger = Logger.getLogger(demo.class);
/*    */   
/*    */   protected void service(HttpServletRequest request, HttpServletResponse response)
/*    */     throws ServletException, IOException
/*    */   {
/* 22 */     System.out.println("ok");
/*    */     
/* 24 */     StringBuffer sb = new StringBuffer();
/* 26 */     for (String name : request.getParameterMap().keySet()) {
/* 27 */       sb.append(name + "=" + request.getParameter(name) + "&");
/*    */     }
/* 30 */     this.logger.info(sb.toString());
/* 31 */     response.getWriter().write("ok");
/* 32 */     response.getWriter().flush();
/*    */   }
/*    */ }


/* Location:           C:\Users\Administrator.WIN-3ASOG40POCS\Desktop\新建文件夹 (3)\WEB-INF\classes\
 * Qualified Name:     demo
 * JD-Core Version:    0.7.0.1
 */