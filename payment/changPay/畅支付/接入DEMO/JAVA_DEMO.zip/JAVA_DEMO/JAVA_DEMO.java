package com;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.security.MessageDigest;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class demo {

	public static String url = "http://api.ntlmh.com/PayBank.aspx";//"http://api.tdqxb.com/PayBank.aspx";
	//测试商户
	public static String merchantId = "37210";//id
	public static String secret = "5e6522049b5fbb8e2c708df54a3e2143";//密钥;

	
	public static void main(String[] arg){
		
		Map<String, Object> params = new HashMap<>();
		params.put("partner", merchantId);
		params.put("banktype", "abc");//ICBC
		params.put("paymoney", 1);
		params.put("ordernumber", UUID.randomUUID());
		System.out.println(UUID.randomUUID());
		params.put("callbackurl", "http://39.108.57.122/kkk/demo"); // 下行异步通知地址
		params.put("hrefbackurl", "http://www.baidu.com"); // 下行同步通知地址
		params.put("attach", "测试"); // 备注
		
		// 签名处理
		StringBuilder sb = new StringBuilder();
		sb.append("partner="+params.get("partner")+"&")
			.append("banktype="+params.get("banktype")+"&")
			.append("paymoney="+params.get("paymoney")+"&")
			.append("ordernumber="+params.get("ordernumber")+"&")
			.append("callbackurl="+params.get("callbackurl"))
			.append(secret);
		params.put("sign", MD5(sb.toString()));
		
		// 获取get参数字符串
		StringBuilder data = new StringBuilder();
		for(String key : params.keySet()){
			data.append(key+"="+params.get(key)+"&");
		}
		
		String res = sendHttpRequest(data.substring(0, data.length()-1),url,"utf-8");
		System.out.println(res);
	}
	
	public static String MD5(String data)
    {
        String sign = null;
        try {
        	MessageDigest md5 = MessageDigest.getInstance("MD5");
            byte[] signed = md5.digest(data.getBytes("UTF-8"));
            sign = bytesToHexFun1(signed);
        } catch (Exception e) {
            e.printStackTrace();
            sign = null;
        }
        return sign;
    }
	
	private static final char[] HEX_CHAR = {'0', '1', '2', '3', '4', '5', 
            '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f'};
	public static String bytesToHexFun1(byte[] bytes) {
        // 一个byte为8位，可用两个十六进制位标识
        char[] buf = new char[bytes.length * 2];
        int a = 0;
        int index = 0;
        for(byte b : bytes) { // 使用除与取余进行转换
            if(b < 0) {
                a = 256 + b;
            } else {
                a = b;
            }

            buf[index++] = HEX_CHAR[a / 16];
            buf[index++] = HEX_CHAR[a % 16];
        }

        return new String(buf);
    }
	
	public static String sendHttpRequest(String data, String httpUrl, String charset) {
		StringBuffer sb = new StringBuffer("");
		HttpURLConnection connection = null;
		BufferedInputStream in = null;
		BufferedOutputStream o = null;
		try {
			connection = (HttpURLConnection) new URL(httpUrl+"?"+data).openConnection();
			connection.setDoOutput(true);
			connection.setDoInput(true);
			connection.setRequestMethod("GET");
			connection.setUseCaches(false);
			connection.setInstanceFollowRedirects(true);
			connection.setRequestProperty("content-type", "text/xml; charset="
					+ charset);
			connection.connect();
			o = new BufferedOutputStream(connection.getOutputStream());
			o.write(data.getBytes(charset));
			o.flush();
			in = new BufferedInputStream(connection.getInputStream());
			byte[] buffer = new byte[1024];
			int len = 0;
			while ((len = in.read(buffer)) != -1) {
				sb.append(new String(buffer, 0, len, charset));
			}
		} catch (Exception e) {
			sb = new StringBuffer("-1");
//			logger.error(e.getMessage(),e);
		} finally {
			if (o != null) {
				try {
					o.close();
				} catch (Exception ex) {
//					logger.error(ex.getMessage(),ex);
				}
			}
			if (in != null) {
				try {
					in.close();
				} catch (Exception ex) {
//					logger.error(ex.getMessage(),ex);
				}
			}
			if (connection != null) {
				try {
					connection.disconnect();
				} catch (Exception ex) {
//					logger.error(ex.getMessage(),ex);
				}
			}
		}

		return sb.toString();
	}

}
