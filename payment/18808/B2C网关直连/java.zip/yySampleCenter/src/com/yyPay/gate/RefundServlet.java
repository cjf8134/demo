package com.yyPay.gate;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.crypto.Data;

import com.yyPay.util.Aes;
import com.yyPay.util.yyPlusUtil;
import com.yyPay.util.HttpClientUtil;
import com.yyPay.util.JsonUtils;



public class RefundServlet  extends HttpServlet {

	private String URL="http://paymentapi.emaxcard.com/OrderRefund";//正式
//	private String URL="http://testpapi.shenbianhui.cn/ OrderRefund";//测试
	/**
	 * 
	 * @Description 退款请求转发逻辑
	 * @param @param request
	 * @param @param response
	 * @param @throws ServletException
	 * @param @throws IOException  
	 * @return  
	 * @author  FanXiao
	 * @throws IOException 
	 * @date  2018年6月28日
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {
		System.out.println("##进入处理退款请求逻辑##");
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");
		Date date = new Date();
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyyMMddHHmmss");
//		String keys="f3e48ca0b0c23a1219f23f0c3849f48c";
		String sign=null;
		
		//组建参数
		String orderNo = request.getParameter("orderNo");
		String merCode = request.getParameter("merCode");
		String dateTime = simpleDateFormat.format(date);
		String refundOrderNo = UUID.randomUUID().toString().replaceAll("-", "");
		String refundOrderAmount = request.getParameter("refundOrderAmount");
		String keys = request.getParameter("keys");
//		String subStrKey = keys.substring(0,16);
		Map<String, String> refundPara = new HashMap<String, String>();
		refundPara.put("orderNo", orderNo);
		refundPara.put("merCode", merCode);
		refundPara.put("dateTime", dateTime);
		refundPara.put("refundOrderNo", refundOrderNo);
		refundPara.put("refundOrderAmount", refundOrderAmount);

		String url = Aes.getSignPlainText(refundPara);
		System.out.println("/****"+url+"****/");
		
		try {
			sign = Aes._md5Encode(url);
		} catch (Exception e) {
			System.out.println("系统繁忙[02]请稍后重试！");
			e.printStackTrace();
		}
		refundPara.put("sign", sign);
		String reqrefundPara = JsonUtils.toJson(refundPara);
		System.out.println("退款请求参数 = "+reqrefundPara);
		String reqData = HttpClientUtil.doPost(URL, reqrefundPara);
		System.out.println("同步返回数据 = "+reqData);
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
