package com.yyPay.gate;

import java.io.IOException;
import java.io.PrintWriter;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;

import com.yyPay.util.yyPlusUtil;
import com.yyPay.util.HttpClientUtil;
import com.yyPay.util.HttpUtils;
import com.yyPay.util.JsonUtils;
import com.yyPay.util.PropertiesTools;

import net.sf.json.JSONObject;

public class GateServlet extends HttpServlet {
/**
 * @author wyq
 * 
 */
	public static void main(String[] args) {
		
	}
	
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
			response.setContentType("text/html;");
			request.setCharacterEncoding("UTF-8");
			String URL =  PropertiesTools.getPropertirsStringValue("formalGateWayURL");
			String merCode = PropertiesTools.getPropertirsStringValue("merCode");
			String orderAmount = request.getParameter("orderAmount");
			String returnAddress = request.getParameter("returnAddress");
			String backAddress = request.getParameter("backAddress");
			String payType = request.getParameter("payType");
			String bankCardType = request.getParameter("bankCardType");
	     	String bankCode = request.getParameter("bankCode");
			String str = PropertiesTools.getTimeOrderNo("WG", "yyyyMMddHHmmss");
			System.out.println("订单号："+str);
			HashMap <String,String> payParam=new HashMap<String,String>();
			
			payParam.put("orderNo", str);
			payParam.put("orderAmount",new BigDecimal(orderAmount.toString()).multiply(new BigDecimal("100")).intValue()+"");
			payParam.put("returnAddress", returnAddress);
			payParam.put("backAddress", backAddress);
			payParam.put("merCode", merCode);
			payParam.put("dateTime", PropertiesTools.getTimeFormat());
			payParam.put("payType", payType);
			payParam.put("bankCardType", bankCardType);
			payParam.put("bankCode", bankCode);
			
			String url = yyPlusUtil.getSignPlainText(payParam);
			System.out.println("加密参数："+url);
			String sign=null;
			try {
				sign=yyPlusUtil._md5Encode(url);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			payParam.put("sign", sign);

			String reqStr= JsonUtils.toJson(payParam);
			System.out.println("打印请求参数："+reqStr);
			String reqData = HttpClientUtil.doPost(URL, reqStr);
	        String [] arrstr = reqData.split( "\"");
			String location = "http://payment.emaxcard.com"+arrstr[1].replace("&amp;", "&");
	         response.sendRedirect(location);
		}
		
		
	}


