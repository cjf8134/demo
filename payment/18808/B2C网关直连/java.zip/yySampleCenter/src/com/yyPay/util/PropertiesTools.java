package com.yyPay.util;

import java.io.FileInputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.ResourceBundle;
import java.util.UUID;

/**
 * 
 * ClassName: PropertiesTools 
 * @Description: TODO
 * @author FanXiao
 * @date 2018年7月9日
 */
public class PropertiesTools {
	
	private static final String FILENAME = "resources/gateway";
	/**
	 * 
	 * @Description 获取配置文件map
	 * @param @param name
	 * @param @return
	 * @param @throws Exception  
	 * @return  
	 * @throws Exception
	 * @author  FanXiao
	 * @date  2018年7月9日
	 */
	public static Map<String, String> getPropertirsMapValue(Map<String, String> name) {
		ResourceBundle resource = ResourceBundle.getBundle(FILENAME);
		System.out.println("-------------------开始读取配置信息---------------------");
	
				for (Map.Entry<String, String> entry : name.entrySet()) {
					name.put(entry.getKey(), resource.getString(entry.getKey()));
				}
				System.out.println("------------------------读取配置信息成功！------------------");


		

		return name;
	}
	
	/**
	 * 
	 * @Description 获取配置文件单值
	 * @param @param name
	 * @param @return
	 * @param @throws Exception  
	 * @return  
	 * @throws Exception
	 * @author  FanXiao
	 * @date  2018年7月9日
	 */

	public static String getPropertirsStringValue(String name){
		String value = "";
//		try {
			ResourceBundle resource = ResourceBundle.getBundle(FILENAME);
				value =  resource.getString(name);
//		} catch (Exception e) {
//			System.out.println("读取配置文件异常！");
//		}
		
		
		
		
		return value;
	}
	
	/**
	 * 
	 * @Description 获取指定格式的订单号
	 * @param @param pre前缀
	 * @param @param TimeFormat时间格式
	 * @param @return  
	 * @return  
	 * @throws Exception
	 * @author  FanXiao
	 * @date  2018年7月10日
	 */
	public static String getTimeOrderNo(String pre,String TimeFormat) {
		Date date = new Date();
		SimpleDateFormat formatter = new SimpleDateFormat(TimeFormat);
		String dateStr = formatter.format(date);
		String uuid = UUID.randomUUID().toString().replaceAll("-", "").substring(6, 12);
		String orderNo = pre+dateStr+uuid;
		return orderNo;
		
	}
	/**
	 * 
	 * @Description 获取当前时间
	 * @param @return  
	 * @return  
	 * @throws Exception
	 * @author  FanXiao
	 * @date  2018年7月10日
	 */
	public static String getTimeFormat() {
		Date date = new Date();
		SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMddHHmmss");
		String dateStr = formatter.format(date);
		return dateStr;
		
	}
	public static void main(String[] args) throws Exception {
		
	}

}
