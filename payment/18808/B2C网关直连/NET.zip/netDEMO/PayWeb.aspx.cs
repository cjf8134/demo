﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace DEMO
{
    public partial class PayWeb : System.Web.UI.Page
    {
        public string mercode = System.Configuration.ConfigurationManager.AppSettings["mercode"];
        public string entcode = "";
        public string orderno = System.Guid.NewGuid().ToString();
        public string datetime1 = DateTime.Now.AddMinutes(1).ToString("yyyyMMddHHmmss");
        public string sign = "";
        public string url = System.Configuration.ConfigurationManager.AppSettings["urlweb"];
        public string price = "10";
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack) 
            {
                if (Request["price"] != null) 
                {
                    if (Request["price"].ToString().ToCharArray().Where(o=>!Char.IsNumber(o)).Count()==0)
                    {
                        price = Request["price"];
                    }
                }
                Dictionary<string, string> dc = new Dictionary<string, string>();
                dc.Add("orderNo", orderno);
                dc.Add("orderAmount", price);
                dc.Add("source", "web");
                dc.Add("merCode", mercode);
                dc.Add("dateTime", datetime1);
                dc.Add("backAddress", "http://www.baidu.com");
                dc.Add("returnAddress", "http://www.baidu.com");
                string keys = Common.Helper.zckey(dc) + System.Configuration.ConfigurationManager.AppSettings["key"];
                sign = Common.Helper.Encrypt_MD5(keys);
            }
        }
    }
}