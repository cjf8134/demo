﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DEMO.Common;
using System.Text;
using System.IO;

namespace DEMO
{
    public partial class DFOrderSearch : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack) 
            {
                TextBox2.Text = DateTime.Now.ToString("yyyyMMdd");
                TextBox3.Text = System.Configuration.ConfigurationManager.AppSettings["mercode"];
            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Dictionary<string, string> sDic = new Dictionary<string, string>();
            sDic.Add("orderId", TextBox1.Text);
            sDic.Add("orderDt", TextBox2.Text);
            sDic.Add("merCode", TextBox3.Text);
            string key = System.Configuration.ConfigurationManager.AppSettings["key"];
            string host = System.Configuration.ConfigurationManager.AppSettings["url"];
            string _signValue = Common.Helper.zckey(sDic);

            sDic.Add("sign", Common.Helper.Encrypt_MD5(_signValue + key));
            string json = "{\"orderId\":\"" + sDic["orderId"] + "\",\"orderDt\":\"" + sDic["orderDt"] + "\",\"sign\":\"" + sDic["sign"] + "\",\"merCode\":\"" + sDic["merCode"] + "\"}";
            byte[] bytes = Encoding.UTF8.GetBytes(json);
            HttpHelper ht = new HttpHelper(host + "pay/AgentPayOrderSearch");
            ht.Request.Method = "post";
            ht.Request.ContentLength = bytes.Length;
            ht.Request.ContentType = "application/json";
            using (Stream requestStream = ht.Request.GetRequestStream())
            {
                requestStream.Write(bytes, 0, bytes.Length);
            }
            string str = ht.GetResponseSTRING().Replace("\"", "'");
            Response.Write(str);
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            TextBox2.Text = DateTime.Now.ToString("yyyyMMdd");
            TextBox3.Text = System.Configuration.ConfigurationManager.AppSettings["mercode"];
        }
    }
}