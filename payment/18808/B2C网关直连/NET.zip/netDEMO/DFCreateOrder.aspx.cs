﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DEMO.Common;
using System.Text;
using System.IO;

namespace DEMO
{
    public partial class DFCreateOrder : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack) 
            {
                TextBox1.Text = "10";
                TextBox2.Text = "df" + DateTime.Now.ToString("yyyyMMddHHmmss");
                TextBox3.Text = DateTime.Now.ToString("yyyyMMddHHmmss");
                TextBox9.Text = "00";
                TextBox10.Text = "0";
                TextBox11.Text = System.Configuration.ConfigurationManager.AppSettings["mercode"];
            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            string key = System.Configuration.ConfigurationManager.AppSettings["key"];
            string host = System.Configuration.ConfigurationManager.AppSettings["url"];
            string mercode = TextBox11.Text;
            Dictionary<string, string> sDic = new Dictionary<string, string>();
            sDic.Add("bankMobile", TextBox5.Text == "" ? "" : CommonSecurity_AESService.AesEncrypt(TextBox5.Text, key.Substring(0, 16)));
            sDic.Add("accType", TextBox10.Text);
            sDic.Add("cardByName", TextBox6.Text == "" ? "" : CommonSecurity_AESService.AesEncrypt(TextBox6.Text, key.Substring(0, 16)));
            sDic.Add("cardByNo", TextBox7.Text == "" ? "" : CommonSecurity_AESService.AesEncrypt(TextBox7.Text, key.Substring(0, 16)));
            sDic.Add("idNumber", TextBox8.Text == "" ? "" : CommonSecurity_AESService.AesEncrypt(TextBox8.Text, key.Substring(0, 16)));
            sDic.Add("idType", TextBox9.Text);
            sDic.Add("merCode", mercode);
            sDic.Add("orderId", TextBox2.Text);
            sDic.Add("totalAmount", TextBox1.Text);
            sDic.Add("tradeTime", TextBox3.Text);
            sDic.Add("bankCode", TextBox4.Text);
            string _signValue = Common.Helper.zckey(sDic);

            sDic.Add("sign", Common.Helper.Encrypt_MD5(_signValue + key));
            string json = "{\"tradeTime\":\"" + sDic["tradeTime"] + "\",\"accType\":\"" + sDic["accType"] + "\",\"idType\":\"" + sDic["idType"] + "\",\"idNumber\":\"" + sDic["idNumber"]
                + "\",\"cardByName\":\"" + sDic["cardByName"] + "\",\"cardByNo\":\"" + sDic["cardByNo"] + "\",\"bankMobile\":\"" + sDic["bankMobile"] + "\",\"orderId\":\"" + sDic["orderId"] + "\",\"totalAmount\":\"" + sDic["totalAmount"] + "\",\"sign\":\"" + sDic["sign"] + "\",\"merCode\":\"" + sDic["merCode"] + "\",\"bankCode\":\"" + sDic["bankCode"] + "\"}";
            byte[] bytes = Encoding.UTF8.GetBytes(json);
            HttpHelper ht = new HttpHelper(host + "/pay/AgentPayToCard");
            ht.Request.Method = "post";
            ht.Request.ContentLength = bytes.Length;
            ht.Request.ContentType = "application/json";
            using (Stream requestStream = ht.Request.GetRequestStream())
            {
                requestStream.Write(bytes, 0, bytes.Length);
            }
            string str = ht.GetResponseSTRING().Replace("\"", "'");
            Response.Write(str);
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            TextBox1.Text = "10";
            TextBox2.Text = "df" + DateTime.Now.ToString("yyyyMMddHHmmss");
            TextBox3.Text = DateTime.Now.ToString("yyyyMMddHHmmss");
            TextBox9.Text = "00";
            TextBox10.Text = "0";
            TextBox11.Text = System.Configuration.ConfigurationManager.AppSettings["mercode"];
        }
    }
}