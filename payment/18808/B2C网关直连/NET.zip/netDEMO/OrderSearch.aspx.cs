﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Text;
using DEMO.Common;
using System.IO;

namespace DEMO
{
    public partial class OrderSearch : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack) 
            {
                TextBox2.Text = DateTime.Now.ToString("yyyyMMddHHmmss");
                TextBox3.Text = System.Configuration.ConfigurationManager.AppSettings["mercode"];
            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            
            string orderNo = TextBox1.Text;
            string dateTime = TextBox2.Text;
            string merCode = TextBox3.Text;
            string key = System.Configuration.ConfigurationManager.AppSettings["key"];
            string host = System.Configuration.ConfigurationManager.AppSettings["url"];

            Dictionary<string, string> sDic = new Dictionary<string, string>();
            sDic.Add("orderNo", orderNo);
            sDic.Add("merCode", merCode);
            sDic.Add("dateTime", dateTime);
            string _signValue =Common.Helper.zckey(sDic);
            sDic.Add("sign", Common.Helper.Encrypt_MD5(_signValue + key));
            // 二维码类型 1微信 2支付宝
            string json = "{\"orderNo\":\"" + sDic["orderNo"] + "\",\"merCode\":\"" + sDic["merCode"] + "\",\"dateTime\":\"" + sDic["dateTime"] + "\",\"sign\":\"" + sDic["sign"] + "\"}";
            byte[] bytes = Encoding.UTF8.GetBytes(json);
            HttpHelper ht = new HttpHelper(host + "/QRCode/GetOrder");
            ht.Request.Method = "post";
            ht.Request.ContentLength = bytes.Length;
            ht.Request.ContentType = "application/json";
            using (Stream requestStream = ht.Request.GetRequestStream())
            {
                requestStream.Write(bytes, 0, bytes.Length);
            }
            string str = ht.GetResponseSTRING().Replace("\"", "'");
            Response.Write(str);
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            //System.Threading.Thread.CurrentThread.Name =System.Guid.NewGuid().ToString();
            //Response.Write(System.Threading.Thread.CurrentThread.Name);
            TextBox2.Text = DateTime.Now.ToString("yyyyMMddHHmmss");
            TextBox3.Text = System.Configuration.ConfigurationManager.AppSettings["mercode"];
        }
    }
}