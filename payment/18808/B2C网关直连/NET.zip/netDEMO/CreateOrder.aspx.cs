﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using System.Text;
using DEMO.Common;

namespace DEMO
{
    public partial class CreateOrder : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack) 
            {
                TextBox1.Text = "1";
                TextBox2.Text = "cs" + DateTime.Now.ToString("yyyyMMddHHmmss");
                RadioButton1.Checked = true;
                TextBox4.Text = DateTime.Now.ToString("yyyyMMddHHmmss");
                TextBox5.Text = "http://www.baidu.com";
                TextBox6.Text = "cs";
                TextBox7.Text = "30";
                TextBox8.Text = System.Configuration.ConfigurationManager.AppSettings["mercode"];
            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            string orderNo=TextBox2.Text;
            string orderAmount=TextBox1.Text;
            string callbackUrl=TextBox5.Text;
            string productDesc=TextBox6.Text;
            string merCode=TextBox8.Text;
            string dateTime = TextBox4.Text;
            string validityNum = TextBox7.Text;
            string payType = "2";
            string key = System.Configuration.ConfigurationManager.AppSettings["key"];
            string host = System.Configuration.ConfigurationManager.AppSettings["url"];
            if (RadioButton1.Checked)
            {
                payType = "1";
            }
            Dictionary<string, string> sDic = new Dictionary<string, string>();
            sDic.Add("orderNo", orderNo);
            sDic.Add("orderAmount", orderAmount);
            sDic.Add("callbackUrl", callbackUrl);
            sDic.Add("payType", payType);
            sDic.Add("productDesc", productDesc);
            sDic.Add("merCode", merCode);
            sDic.Add("dateTime", dateTime);
            sDic.Add("validityNum", validityNum);
            string _signValue = Common.Helper.zckey(sDic);
            sDic.Add("sign", Common.Helper.Encrypt_MD5(_signValue + key));
            string json = "{\"orderNo\":\"" + sDic["orderNo"] + "\",\"orderAmount\":\"" + sDic["orderAmount"] + "\",\"callbackUrl\":\"" + sDic["callbackUrl"] + "\",\"payType\":\""
                + sDic["payType"] + "\",\"productDesc\":\"" + sDic["productDesc"] + "\",\"merCode\":\"" + sDic["merCode"] + "\",\"dateTime\":\"" + sDic["dateTime"] + "\",\"validityNum\":\"" + sDic["validityNum"] + "\",\"sign\":\"" + sDic["sign"] + "\"}";
            byte[] bytes = Encoding.UTF8.GetBytes(json);
            HttpHelper ht = new HttpHelper(host + "/QRCode/CreateOrder");
            ht.Request.Method = "post";
            ht.Request.ContentLength = bytes.Length;
            ht.Request.ContentType = "application/json";
            using (Stream requestStream = ht.Request.GetRequestStream())
            {
                requestStream.Write(bytes, 0, bytes.Length);
            }
            string str = ht.GetResponseSTRING().Replace("\"", "'").Replace("\\u0026", "&");
            Response.Write(str);
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            TextBox1.Text = "1";
            TextBox2.Text = "cs" + DateTime.Now.ToString("yyyyMMddHHmmss");
            RadioButton1.Checked = true;
            TextBox4.Text = DateTime.Now.ToString("yyyyMMddHHmmss");
            TextBox5.Text = "http://www.baidu.com";
            TextBox6.Text = "cs";
            TextBox7.Text = "30";
            TextBox8.Text = System.Configuration.ConfigurationManager.AppSettings["mercode"];
        }
    }
}