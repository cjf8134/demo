﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Security.Cryptography;
using System.Text;

namespace DEMO.Common
{
    public class Helper
    {
        public static string zckey(Dictionary<string, string> key)
        {
            key = key.OrderBy(o => o.Key).ToDictionary(o => o.Key, p => p.Value);
            //OrderBy(o => o.Key).ToDictionary(o => o.Key, p => p.Value)

            string md5key = "";
            foreach (var item in key)
            {
                if ("" == md5key)
                {
                    md5key = item.Key + "=" + item.Value.Trim();
                }
                else
                {
                    md5key += "&" + item.Key + "=" + item.Value.Trim();
                }
            }
            return md5key;
        }

        public static string Encrypt_MD5(string inputString)
        {
            MD5 md5 = new MD5CryptoServiceProvider();
            byte[] b = Encoding.UTF8.GetBytes(inputString);
            b = md5.ComputeHash(b);
            string ret = "";
            for (int i = 0; i < b.Length; i++)
                ret += b[i].ToString("x").PadLeft(2, '0');

            return ret;
        }
    }
}