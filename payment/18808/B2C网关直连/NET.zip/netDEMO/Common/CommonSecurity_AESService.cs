﻿/********************************************************************************
** auth： shizhonghua

** date： 20150714

** desc：AES加密解密

** Ver:  V1.0.0
*********************************************************************************/

namespace DEMO.Common
{
    using System;
    using System.IO;
    using System.Security.Cryptography;
    using System.Text;
    public class CommonSecurity_AESService
    {
        /// <summary>
        /// AES加密
        /// </summary>
        /// <param name="EncryptString"></param>
        /// <returns></returns>
        //public static string AESEncrypt(string EncryptString)
        //{
        //    return AESEncrypt(EncryptString, CommonDefault.Default_AesKey);
        //}

        /// <summary>
        /// AES加密
        /// </summary>
        /// <param name="EncryptString"></param>
        /// <returns></returns>
        public static string AESEncryptKey(string EncryptString,string AesKey)
        {
            return AESEncrypt(EncryptString, AesKey);
        }

        /// <summary>  
        /// AES + Base64加密  
        /// </summary>  
        /// <param name="content">需要加密的内容</param>  
        /// <param name="password">加密密钥</param>  
        /// <param name="charsetName">编码类型 null或""则默认UTF-8</param>  
        /// <returns></returns>  
        public static string Encrypt(string content, string password, string charsetName)  
        {  
            charsetName = string.IsNullOrEmpty(charsetName) ? "UTF-8" : charsetName;  
            Encoding encoding = Encoding.GetEncoding(charsetName);  
            //password = ShortMD5(password, charsetName);  
            byte[] plainBytes = encoding.GetBytes(content);  
            byte[] keyBytes = encoding.GetBytes(password);  
            Aes kgen = Aes.Create("AES");  
            kgen.Mode = CipherMode.ECB;  
            kgen.Key = keyBytes;  
            ICryptoTransform cTransform = kgen.CreateEncryptor();  
            byte[] resultArray = cTransform.TransformFinalBlock(plainBytes, 0, plainBytes.Length);  
            return Convert.ToBase64String(resultArray, 0, resultArray.Length);  
        }  


        /// <summary>
        /// AES加密
        /// </summary>
        /// <param name="EncryptString"></param>
        /// <param name="EncryptKey"></param>
        /// <returns></returns>
        public static string AESEncrypt(string EncryptString, string EncryptKey)
        {
            string m_strEncrypt = "";
            byte[] m_btIV = Convert.FromBase64String("Rkb4jvUy/ye7Cd7k89QQgQ==");
            Rijndael m_AESProvider = Rijndael.Create();
            try
            {
                byte[] m_btEncryptString = Encoding.Default.GetBytes(EncryptString);
                MemoryStream m_stream = new MemoryStream();
                CryptoStream m_csstream = new CryptoStream(m_stream, m_AESProvider.CreateEncryptor(Encoding.Default.GetBytes(EncryptKey), m_btIV), CryptoStreamMode.Write);
                m_csstream.Write(m_btEncryptString, 0, m_btEncryptString.Length); m_csstream.FlushFinalBlock();
                m_strEncrypt = Convert.ToBase64String(m_stream.ToArray());
                m_stream.Close(); m_stream.Dispose();
                m_csstream.Close(); m_csstream.Dispose();
            }
            catch (IOException ex) { throw ex; }
            catch (CryptographicException ex) { throw ex; }
            catch (ArgumentException ex) { throw ex; }
            catch (Exception ex) { throw ex; }
            finally { m_AESProvider.Clear(); }
            return m_strEncrypt;
        }
        /// <summary>
        /// AES解密
        /// </summary>
        /// <param name="DecryptString"></param>
        /// <returns></returns>
        //public static string AESDecrypt(string DecryptString)
        //{
        //    return AESDecrypt(DecryptString, CommonDefault.Default_AesKey);
        //}

        /// <summary>
        /// AES解密
        /// </summary>
        /// <param name="DecryptString"></param>
        /// <returns></returns>
        public static string AESDecryptKey(string DecryptString,string AesKey)
        {
            return AESDecrypt(DecryptString, AesKey);
        }
        /// <summary>
        /// AES解密
        /// </summary>
        /// <param name="DecryptString"></param>
        /// <param name="DecryptKey"></param>
        /// <returns></returns>
        public static string AESDecrypt(string DecryptString, string DecryptKey)
        {
            string m_strDecrypt = "";
            byte[] m_btIV = Convert.FromBase64String("Rkb4jvUy/ye7Cd7k89QQgQ==");
            Rijndael m_AESProvider = Rijndael.Create();
            try
            {
                byte[] m_btDecryptString = Convert.FromBase64String(DecryptString);
                MemoryStream m_stream = new MemoryStream();
                CryptoStream m_csstream = new CryptoStream(m_stream, m_AESProvider.CreateDecryptor(Encoding.Default.GetBytes(DecryptKey), m_btIV), CryptoStreamMode.Write);
                m_csstream.Write(m_btDecryptString, 0, m_btDecryptString.Length); m_csstream.FlushFinalBlock();
                m_strDecrypt = Encoding.Default.GetString(m_stream.ToArray());
                m_stream.Close(); m_stream.Dispose();
                m_csstream.Close(); m_csstream.Dispose();
            }
            catch (IOException ex) { throw ex; }
            catch (CryptographicException ex) { throw ex; }
            catch (ArgumentException ex) { throw ex; }
            catch (Exception ex) { throw ex; }
            finally { m_AESProvider.Clear(); }
            return m_strDecrypt;
        }


        /// <summary>
        ///  AES 加密
        /// </summary>
        /// <param name="str"></param>
        /// <param name="key"></param>
        /// <returns></returns>
        public static string AesEncrypt(string str, string key)
        {
            if (string.IsNullOrEmpty(str)) return null;
            Byte[] toEncryptArray = Encoding.UTF8.GetBytes(str);

            System.Security.Cryptography.RijndaelManaged rm = new System.Security.Cryptography.RijndaelManaged
            {
                Key = Encoding.UTF8.GetBytes(key),
                Mode = System.Security.Cryptography.CipherMode.ECB,
                Padding = System.Security.Cryptography.PaddingMode.PKCS7
            };

            System.Security.Cryptography.ICryptoTransform cTransform = rm.CreateEncryptor();
            Byte[] resultArray = cTransform.TransformFinalBlock(toEncryptArray, 0, toEncryptArray.Length);

            return Convert.ToBase64String(resultArray, 0, resultArray.Length);
        }

        /// <summary>
        ///  AES 解密
        /// </summary>
        /// <param name="str"></param>
        /// <param name="key"></param>
        /// <returns></returns>
        public static string AesDecrypt(string str, string key)
        {
            string m_strDecrypt = "";
            if (string.IsNullOrEmpty(str)) return m_strDecrypt;
            try
            {
                Byte[] toEncryptArray = Convert.FromBase64String(str);

                System.Security.Cryptography.RijndaelManaged rm = new System.Security.Cryptography.RijndaelManaged
                {
                    Key = Encoding.UTF8.GetBytes(key),
                    Mode = System.Security.Cryptography.CipherMode.ECB,
                    Padding = System.Security.Cryptography.PaddingMode.PKCS7
                };

                System.Security.Cryptography.ICryptoTransform cTransform = rm.CreateDecryptor();
                Byte[] resultArray = cTransform.TransformFinalBlock(toEncryptArray, 0, toEncryptArray.Length);
                m_strDecrypt = Encoding.UTF8.GetString(resultArray);
            }
            catch (Exception ex) { return m_strDecrypt; }
            return m_strDecrypt;
        }
    }
}
