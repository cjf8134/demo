<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>网银支付</title>
    <link rel="stylesheet" type="text/css" href="css/sand.css">
</head>
<body>
<div>
    <div id="main">
        <div id="head">
            <dl class="sandpay_link">
                <a target="_blank" href="https://www.baidu.com/"><span>支付首页</span></a>
            </dl>
            <span class="title"> 网关支付1.0 统一下单接口</span>
        </div>
        <div class="cashier-nav"></div>
        <div class="center">
            <form action="orderpay.php" method="post" name="sandpay">
                <div id="body" style="clear:left">
                    <dl class="content">
                        <dt>[mch_id]商户号:</dt>
                        <dd>
                            <span class="null-star">*</span>
                            <input type="text" name="mch_id" value="10000015"/>
                        </dd>
						<dt>[user_id]用户id:</dt>
                        <dd>
                            <span class="null-star">*</span>
                            <input type="text" name="user_id" value="1234567"/>
                        </dd>
						<dt>[user_ip]用户ip:</dt>
                        <dd>
                            <span class="null-star">*</span>
                            <input type="text" name="user_ip" value="127.0.0.1"/>
                        </dd>
                        <dt>[out_order_no]商户订单号:</dt>
                        <dd>
                            <span class="null-star">*</span>
                            <input type="text" name="out_order_no" value="<?php echo "2017090000" . time(); ?>"/>
                        </dd>
                        <dt>[payment_fee]订单金额:</dt>
                        <dd>
                            <span class="null-star">*</span>
                            <input type="text" name="payment_fee" value="100"/>
                        </dd>
                        <dt>[card_type]卡类型:</dt>
                        <dd>
                            <span class="null-star">*</span>
                            <input type="text" name="card_type" value='1'/>
                        </dd>
                        <dt>[body]订单描述:</dt>
                        <dd>
                            <span class="null-star">*</span>
                            <input type="text" name="body" value='老板买包烟'/>
                        </dd>
                        <dt>[pay_type]支付类型:</dt>
                        <dd>
                            <span class="null-star">*</span>
                            <input type="text" name="pay_type" value='B2C'/>
                        </dd>
                        <dt>[bank_code]银行编码:</dt>
                        <dd>
                            <span class="null-star">*</span>
                            <select name="bank_code">
                                <option value="ICBC">工商银行</option>
                                <option value="CCB" selected="selected">建设银行</option>
                                <option value="ABC">农业银行</option>
                                <option value="CMB">招商银行</option>
                                <option value="COMM">交通银行</option>
                                <option value="BOC">中国银行</option>
                                <option value="CEB">光大银行</option>
                                <option value="CMBC">民生银行</option>
                                <option value="CIB">兴业银行</option>
                                <option value="CITIC">中信银行</option>
                                <option value="GDB">广发银行</option>
                                <option value="SPDB">浦发银行</option>
                                <option value="PAB">平安银行</option>
                                <option value="HXB">华夏银行</option>
                                <option value="BONB">宁波银行</option>
                                <option value="BEA">东亚银行</option>
                                <option value="BOSH">上海银行</option>
                                <option value="PSBC">中国邮储银行</option>
                                <option value="BONJ">南京银行</option>
                                <option value="SRCB">上海农商行</option>
                                <option value="BOBH">渤海银行</option>
                                <option value="BOCD">成都银行</option>
                                <option value="BOB">北京银行</option>
                                <option value="HUISB">徽商银行</option>
                                <option value="BOTJ">天津银行</option>
                            </select>
                        </dd>
                        <dt>[clientIp]客户端IP:</dt>
                        <dd>
                            <span class="null-star">*</span>
                            <input type="text" name="clientIp" value="127.0.0.1"/>
                        </dd>
                        <dt>[notifyUrl]异步通知地址:</dt>
                        <dd>
                            <span class="null-star">*</span>
                            <input type="text" name="notifyUrl"
                                   value='http://192.168.22.171/sandpay-qr-phpdemo.bak/test/dist/notifyurl.php'>
                        </dd>
                        <dt>[frontUrl]前台通知地址:</dt>
                        <dd>
                            <span class="null-star">*</span>
                            <input type="text" name="frontUrl"
                                   value='http://www.baidu.com'>
                        </dd>
                        <dt></dt>
                        <dd>
	                        <span class="new-btn-login-sp">
	                            <button class="new-btn-login" type="submit" style="text-align:center;">确 认</button>
	                        </span>
                        </dd>
                    </dl>
                </div>
            </form>
        </div>
    </div>
</div>
</body>
</html>
