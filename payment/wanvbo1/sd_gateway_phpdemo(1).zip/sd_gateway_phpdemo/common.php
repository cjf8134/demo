<?php
date_default_timezone_set("Asia/Shanghai");

//--------------------------------------------1、基础参数配置------------------------------------------------

const API_HOST = 'https://rpi.ie-pay.com/ecurrencypay/pay';     //下单请求地址
const MD5_KEY = '90842df94a324a479b7cd621967b0d0d'; //md5密钥

//--------------------------------------------end基础参数配置------------------------------------------------

/**
 * MD5签名
 * @param $plainText
 * @return string
 * @throws Exception
 */
function sign($plainText)
{
	$src_str = 'biz_content=' . $plainText . "&key=" . MD5_KEY;
	return strtoupper(md5($src_str));
}

/**
 * MD5验签
 * @param $plainText
 * @param $sign
 * @return int
 * @throws Exception
 */
function verify($plainText, $sign)
{
	$src_str = 'biz_content=' . $plainText . "&key=" . MD5_KEY;
	$ret_sign = strtoupper(md5($src_str));
	if ($sign != $ret_sign) {
        throw new \Exception('签名验证未通过,plainText:' . $plainText . '。sign:' . $sign, '02002');
    }
    return true;
}

/**
 * 发送请求
 * @param $url
 * @param $param
 * @return bool|mixed
 * @throws Exception
 */
function http_post_json($url, $param)
{
    if (empty($url) || empty($param)) {
        return false;
    }
    $param = http_build_query($param);
    try {

        $ch = curl_init();//初始化curl
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $param);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/x-www-form-urlencoded'));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        //正式环境时解开注释
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        $data = curl_exec($ch);//运行curl
        curl_close($ch);

        if (!$data) {
            throw new \Exception('请求出错');
        }

        return $data;
    } catch (\Exception $e) {
        throw $e;
    }
}

function parse_result($result)
{
    $arr = array();
    $response = urldecode($result);
    $arrStr = explode('&', $response);
    foreach ($arrStr as $str) {
        $p = strpos($str, "=");
        $key = substr($str, 0, $p);
        $value = substr($str, $p + 1);
        $arr[$key] = $value;
    }

    return $arr;
}