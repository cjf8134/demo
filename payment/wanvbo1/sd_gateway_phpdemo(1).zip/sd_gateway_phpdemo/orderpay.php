<?php
require('common.php');

if ($_POST) {
    // step1: 拼接data
    $data = array(
		'mch_id' => $_POST['mch_id'],
		'user_id' => $_POST['user_id'],
		'out_order_no' => $_POST['out_order_no'],
		'card_type' => $_POST['card_type'],
		'pay_type' => $_POST['pay_type'],
		'bank_code' => $_POST['bank_code'],
		'payment_fee' => $_POST['payment_fee'],
		'body' => $_POST['body'],
		'notify_url' => $_POST['notifyUrl'],
		'return_url' => $_POST['frontUrl'],
		'user_ip' => $_POST['user_ip'],
    );

    // step2: 签名
	ksort($data);
	$sign_src = json_encode($data,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
    $sign = sign($sign_src);

    // step3: 拼接post数据
    $post = array(
        'sign_type' => 'MD5',
        'biz_content' => $sign_src,
        'signature' => $sign
    );

    // step4: post请求
	//echo "start http_post_json..............";
    $result = http_post_json(API_HOST, $post);
	//echo "start http_post_json..............[".$result."]";

    // step6： 获取credential
	$data = json_decode($result, true);
    if ($data['ret_code'] == "0") {
		verify(json_encode($data['biz_content'],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES),$data['signature']);
        $credential = $data['biz_content']['credential'];
    } else {
        print_r($data['ret_msg']);
    }

} else {
    echo "不是POST传输  ";
}


?>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <meta name="renderer" content="webkit"/>
    <title>Insert title here</title>
    <script type="text/javascript" src="scripts/paymentjs.js"></script>
    <script type="text/javascript" src="scripts/jquery-1.7.2.min.js"></script>
</head>
<body>
<script>
    function wap_pay() {
        var responseText = $("#credential").text();
        console.log(responseText);
        paymentjs.createPayment(responseText, function (result, err) {
            console.log(result);
            console.log(err.msg);
            console.log(err.extra);
        });
    }
</script>

<div style="display: none">
    <p id="credential"><?php echo $credential; ?></p>
</div>
</body>

<script>
    window.onload = function () {
        wap_pay();
    };
</script>
</html>