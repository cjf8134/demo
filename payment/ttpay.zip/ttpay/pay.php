<html>
<head>
    <meta http-equiv="content-type" content="text/html;charset=utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1" /> 
    <title>快捷支付下单</title>
</head>
<body>
  <?php
  header ( "Content-Type:text/html;charset=UTF-8" );
  date_default_timezone_set ( "Asia/Shanghai" );
  require_once 'log.class.php';
  $log=new Log();
  if($_POST){
      include_once "leanworkSDK.php";
      $post=$_POST;
      unset($post['sign']);
      $sign=LeanWorkSDK::makePaySign($post);

      if($sign==$_POST['sign']){
          $log->W("leanwork签名认证:成功");
          echo "处理中,请别关闭页面...";
          $needNotify = $post ["needNotify"];
          $notify_url = $post ["notifyUrl"];
          $needReturn = $post ["needReturn"];
          $return_url = $post ["returnUrl"];
          $sub_merid = $post ["subMerId"];
          $trade_code = $post ["tradeCode"];
          $mer_id = $post ["merId"];
          $user_id = $post ["userId"];
          $order_no = $post ["orderNo"];
          $order_time = date ( 'YmdHis' );
          $order_amt = $post ["orderAmt"];
          $cur_type = $post ["curType"];
          $terminal_type = $post ["cashier_type"];
          $goods_name = $post ["goodsName"];
          $goods_num = $post ["goodsNum"];
          $goods_type = $post ["goodsType"];
          $remark = $post ["remark"];
          $extension = ''; // $_POST["extension"];
          $attach = $post ["attach"];
          $url = $post ["url"];
          $id_card_no = $post ["idCardNo"];
          $realname = $post ["realname"];
          $pay_channels = $post ["pay_channels"];
          $img_url = $post ["img_url"];
          $domain = $post ["domain"];
          $service = '';
          if ('web' == $terminal_type) {
              $service = 'fosun.sumpay.cashier.web.trade.order.apply';
          } else {
              $service = 'fosun.sumpay.cashier.wap.trade.order.apply';
          }
          $parameters = [
              'app_id' => $mer_id,
              'terminal_type' => $terminal_type,
              'version' => '1.0',
              'service' => $service,
              'timestamp' => $order_time,
              'mer_no' => $mer_id,
              'trade_code' => $trade_code,
              'user_id' => $user_id,
              'order_no' => $order_no,
              'order_time' => $order_time,
              'order_amount' => $order_amt,
              'need_notify' => $needNotify,
              'need_return' => $needReturn,
              'goods_name' => $goods_name,
              'goods_num' => $goods_num,
              'goods_type' => $goods_type
          ];

          if ($img_url && "" != $img_url) {
              $parameters ['mer_logo_url'] = $img_url;
          }

          if ($sub_merid && "" != $sub_merid) {
              $parameters ['sub_mer_no'] = $sub_merid;
          }
          if ($notify_url && "" != $notify_url) {
              $parameters ['notify_url'] = $notify_url;
          }
          if ($return_url && "" != $return_url) {
              $parameters ['return_url'] = $return_url;
          }
          if ($cur_type && "" != $cur_type) {
              $parameters ['currency'] = $cur_type;
          }
          if ($pay_channels && "" != $pay_channels) {
              $parameters ['pay_channels'] = $pay_channels;
          }
          if ($remark && "" != $remark) {
              $parameters ['remark'] = $remark;
          }
          if ($extension && "" != $extension) {
              $parameters ['extension'] = $extension;
          }
          if ($attach && "" != $attach) {
              $parameters ['attach'] = $attach;
          }
          if ($realname && "" != $realname) {
              $parameters ['realname'] = $realname;
          }
          if ($id_card_no && "" != $id_card_no) {
              $parameters ['id_no'] = $id_card_no;
          }


          $encrypted_fields = array (
              "mobile_no",
              "card_no",
              "realname",
              "cvv",
              "valid_year",
              "valid_month",
              "id_no",
              "auth_code"
          );
          $charset_change_fields = array (
              "terminal_info",
              "remark",
              "extension",
              "realname",
              "attach"
          );
          $special_fields = array (
              "terminal_info",
              "remark",
              "extension",
              "notify_url",
              "return_url",
              "goods_name",
              "attach",
              "mer_logo_url"
          );
          $defaultCharset = 'UTF-8';
          include 'SumpayService.php';
          $log->W('表单提交');
          $log->W(var_export($parameters,true));
          $returnUrl = execute ( $url, 'GB2312', $parameters, "yixuntiankong.pfx", "sumpay", "yixun.cer", $domain, $charset_change_fields, $encrypted_fields, $special_fields, $defaultCharset );
          $urlHead = substr ( $returnUrl, 0, 4 );
          if (strcasecmp ( $urlHead, 'http' ) != 0) {
              echo iconv ( 'UTF-8', 'GB2312', $returnUrl );
          } else {
              echo <<< HTML
                <form hidden=true method=post action=$returnUrl>
                <input hidden=true type=submit value=ok>
                </form>
                <script>
                document.forms[0].submit();
                </script>
HTML;
          }

      }else{
          $log->W("leanwork签名认证—失败:\n".var_export($_POST,true));
          echo "非法访问";
      }
  }else{
      echo "无效参数";
  }



  
  
  
  
  function getUrl(){
      $str=substr($_SERVER["REQUEST_URI"],0,strrpos($_SERVER["REQUEST_URI"],"/")+1);
      $pageURL = 'http';
      if (isset($_SERVER["HTTPS"]) && $_SERVER["HTTPS"]== "on")
      {
          $pageURL .= "s";
      }
      $pageURL .= "://";
      //$host=$_SERVER["SERVER_NAME"]?$_SERVER["SERVER_NAME"]:$_SERVER["HTTP_HOST"];
      $host=$_SERVER["HTTP_HOST"];
      if ($_SERVER["SERVER_PORT"] != "80")
      {

          $pageURL .=$host. ":" . $_SERVER["SERVER_PORT"];
      }
      else
      {
          $pageURL .= $host;
      }
      return $pageURL.$str;
  }

    //拼接参数
    function ToUrlParams( $query ){
        if ( !$query ) {
            return null;
        }
        ksort( $query );
        $params = array();
        foreach($query as $key => $value){
            $params[] = $key .'='. $value ;
        }
        $data = implode('&', $params);
        return $data;
    }
    //RSA2签名参数
    function rsaSign($data) {
        $private_key_value = APP_KEY;
        $private_key = "-----BEGIN RSA PRIVATE KEY-----\n".$private_key_value."\n-----END RSA PRIVATE KEY-----\n";
        $private_id = openssl_pkey_get_private( $private_key , '');
        openssl_sign($data, $sign, $private_id, OPENSSL_ALGO_SHA256);
        openssl_free_key( $private_id );
        return urlencode(  base64_encode($sign) );
    }
  ?>
</body>
</html> 