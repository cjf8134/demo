<?php
return array(
    "app_id"        => "2018061560384407",
    "cache_dir"     =>"cache",
    "receiveUrl"    =>$_SERVER['HTTP_HOST']."pay.php",
    "pay_url"       => "http://vip.yzhpay.com/Pay_Index.html",
    "pickupUrl"     => "http://localhost/pay/success",
    
    
);




